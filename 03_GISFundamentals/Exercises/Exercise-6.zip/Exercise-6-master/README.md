# Exercise 6

This week we will practice how to work with OpenStreetMap data and conduct network analysis in Python.

- **Exercise 6 is due by Wednesday the 11th of December at 4pm** (day before the next practical session).
- You can gain 20 points from this exercise

## Problems

This week we have two problems that needs solving. Start the exercise from following link:

 - [Exercise-6-problems-1-2.ipynb](Exercise-6-problems-1-2.ipynb)
