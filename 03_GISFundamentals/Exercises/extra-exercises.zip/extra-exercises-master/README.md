# extra-exercises

You can find extra tasks in these notebooks:
- [Extra-tasks.ipynb](Extra-tasks.ipynb)
- [xmas_tree.ipynb](xmas_tree.ipynb)
